package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class OrdersDAO {

	@Autowired  
    JdbcTemplate jdbc;  
    
    public String authenticate(String Cus_id,String Ord_Status) {
    	 String cmd = "select * from Orders where CUS_ID=? " + " AND ORD_STATUS=?";
        List str=jdbc.query(cmd,new Object[] {Cus_id,Ord_Status}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                // TODO Auto-generated method stub
                return rs.getInt("cnt");
            }
            
        });
        return str.get(0).toString();
    }
    public Orders[] autheno(String Cus_id) {
    	 String cmd = "select count(*) cnt from Orders where CUS_ID=? ";
        List<Orders> str = null;
         str=jdbc.query(cmd,new Object[] {Cus_id}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                // TODO Auto-generated method stub
            	Orders o=new Orders();
				o.setORD_ID(rs.getString("oRD_ID"));
				o.setVEN_ID(rs.getString("vEN_ID"));
				o.setWAL_SOURCE(rs.getString("wAL_SOURCE"));
				o.setMEN_ID(rs.getString("mEN_ID"));
				o.setORD_DATE(rs.getString("oRD_DATE"));
				o.setORD_QUANTITY(rs.getString("oRD_QUANTITY"));
				o.setORD_BILLAMOUNT(rs.getString("oRD_BILLAMOUNT"));
				o.setORD_COMMENTS(rs.getString("oRD_COMMENTS"));
				return o;
            }
            
        });
        

    return str.toArray(new Orders[str.size()]);
   
}
}

package com.example.demo;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MainController {
	@Autowired
	private CustomerService customerservice;
	@Autowired
	private MenuService menuservice;
	@Autowired
	private VendorService vendorservice;
	@Autowired
	private OrdersService ordersservice;
	
	@RequestMapping("/")
	public String hello() {
	    return "hello";
	}
	
	@RequestMapping(value="/showcustomer")
    public List<Customer> list() {
        return customerservice.showCustomer();
    }
	
	 @GetMapping("/customer/{id}")
	    public ResponseEntity<Customer> get(@PathVariable String id) {
	        try {
	            Customer customer = customerservice.get(id);
	            return new ResponseEntity<Customer>(customer, HttpStatus.OK);
	        } catch (NoSuchElementException e) {
	            return new ResponseEntity<Customer>(HttpStatus.NOT_FOUND);
	        }      
	    }
	 @RequestMapping("/customerAuthenticate/{user}/{pwd}")
	    public String customerAutneticateion(@PathVariable String user, @PathVariable String pwd) {
	        return customerservice.authenticate(user, pwd);
	    }
	
	 @RequestMapping(value="/showmenu")
	    public List<Menu> list1() {
	        return menuservice.showMenu();
	    }
	 
	 @GetMapping("/menu/{id}")
	    public ResponseEntity<Menu> get1(@PathVariable String id) {
	        try {
	            Menu menu = menuservice.get(id);
	            return new ResponseEntity<Menu>(menu, HttpStatus.OK);
	        } catch (NoSuchElementException e) {
	            return new ResponseEntity<Menu>(HttpStatus.NOT_FOUND);
	        }      
	    }
	 
	 @RequestMapping(value="/showvendor")
	    public List<Vendor> list2() {
	        return vendorservice.showVendor();
	    }
	 
	 @GetMapping("/vendor/{id}")
	    public ResponseEntity<Vendor> get2(@PathVariable String id) {
	        try {
	            Vendor vendor = vendorservice.get(id);
	            return new ResponseEntity<Vendor>(vendor, HttpStatus.OK);
	        } catch (NoSuchElementException e) {
	            return new ResponseEntity<Vendor>(HttpStatus.NOT_FOUND);
	        }      
	    }
	 @RequestMapping("/vendorAuthenticate/{user}/{pwd}")
	    public String autneticateion(@PathVariable String user, @PathVariable String pwd) {
	        return vendorservice.authenticate(user, pwd);
	    }
	 @RequestMapping("/customerAuthen/{user}")
	   public Customer[] authen(@PathVariable String user) {
	       return customerservice.authen(user);
	   }
	 @RequestMapping("/vendorAuthen/{user}")
	   public Vendor[] authenv(@PathVariable String user) {
	       return vendorservice.authenv(user);
	   }
	 
	 @RequestMapping(value="/showorder")
	    public List<Orders> list3() {
	        return ordersservice.showOrders();
	    }
	 
	 @GetMapping("/order/{id}")
	    public ResponseEntity<Orders> get3(@PathVariable String id) {
	        try {
	            Orders orders = ordersservice.get(id);
	            return new ResponseEntity<Orders>(orders, HttpStatus.OK);
	        } catch (NoSuchElementException e) {
	            return new ResponseEntity<Orders>(HttpStatus.NOT_FOUND);
	        }      
	    }
	 @RequestMapping("/orderAuthenticate/{Cus_id}/{Ord_Status}")
	    public String autneticateion1(@PathVariable String Cus_id, @PathVariable String Ord_Status) {
	        return ordersservice.authenticate(Cus_id, Ord_Status);
	    }
	 
	 @RequestMapping("/orderAuthen/{Cus_id}")
	   public Orders[] autheno(@PathVariable String Cus_id) {
	       return ordersservice.autheno(Cus_id);
	   }
}

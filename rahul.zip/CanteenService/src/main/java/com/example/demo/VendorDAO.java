package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class VendorDAO {

	@Autowired  
    JdbcTemplate jdbc;  
    
    public String authenticate(String user,String pwd) {
        String cmd = "select count(*) cnt from Vendor where  VEN_USERNAME=? "
                + " AND VEN_PASSWORD=?";
        List str=jdbc.query(cmd,new Object[] {user,pwd}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                // TODO Auto-generated method stub
                return rs.getInt("cnt");
            }
            
        });
        return str.get(0).toString();
    }
    public Vendor[] authenv(String user) {
        String cmd = "select * from vendor where  VEN_USERNAME=? ";
        List<Vendor> str = null;
         str=jdbc.query(cmd,new Object[] {user}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                // TODO Auto-generated method stub
            	Vendor c=new Vendor();
				c.setVEN_ID(rs.getString("VEN_ID"));
				c.setVEN_NAME(rs.getString("VEN_NAME"));
				c.setVEN_PHONE(rs.getString("VEN_PHONE"));
				c.setVEN_USERNAME(rs.getString("VEN_USERNAME"));
				c.setVEN_PASSWORD(rs.getString("VEN_PASSWORD"));
				c.setVEN_EMAIL(rs.getString("VEN_EMAIL"));
				return c;
            }
            
        });
        

    return str.toArray(new Vendor[str.size()]);
   
}
	
}

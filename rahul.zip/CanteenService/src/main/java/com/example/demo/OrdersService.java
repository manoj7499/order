package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class OrdersService {
	
	 @Autowired
	    private OrdersRepository repo;
	 @Autowired
	    private OrdersDAO dao;

	public List<Orders> showOrders() {
		return repo.findAll();
    }
    
    public Orders get(String id) {
     return repo.findById(id).get();
    
 }
    public void save(Orders orders) {
     repo.save(orders);
 }

	public String authenticate(String cus_id, String ord_Status) {
		// TODO Auto-generated method stub
		return dao.authenticate(cus_id, ord_Status);
	}

	public Orders[] autheno(String cus_id) {
		// TODO Auto-generated method stub
		return dao.autheno(cus_id);
	}

	
}

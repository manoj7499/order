package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerDAO {

	@Autowired  
    JdbcTemplate jdbc;  
    
    public String authenticate(String user,String pwd) {
        String cmd = "select count(*) cnt from Customer where CUS_USERNAME=? "
                + " AND CUS_PASSWORD=?";
        List str=jdbc.query(cmd,new Object[] {user,pwd}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                // TODO Auto-generated method stub
                return rs.getInt("cnt");
            }
            
        });
        return str.get(0).toString();
    }
    public Customer[] authen(String user) {
        String cmd = "select * from Customer where CUS_USERNAME=? ";
        List<Customer> str = null;
         str=jdbc.query(cmd,new Object[] {user}, new RowMapper() {
            @Override
            public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
                // TODO Auto-generated method stub
            	Customer c=new Customer();
				c.setCus_id(rs.getString("cus_id"));
				c.setCus_Name(rs.getString("cus_Name"));
				c.setCus_Phn_No(rs.getString("cus_Phn_No"));
				c.setCus_Username(rs.getString("cus_Username"));
				c.setCus_Password(rs.getString("cus_Password"));
				c.setCus_Email(rs.getString("cus_Email"));
				return c;
            }
            
        });
        

    return str.toArray(new Customer[str.size()]);
   
}
}


package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Orders {
	
    private String ORD_ID;
    private String Cus_id;
    private String VEN_ID;
    private String WAL_SOURCE;
    private String MEN_ID;
    private String ORD_DATE;
    private String ORD_QUANTITY;
    private String ORD_BILLAMOUNT;
    private String ORD_STATUS;
    private String ORD_COMMENTS;
    
    @Id
	public String getORD_ID() {
		return ORD_ID;
	}
	public void setORD_ID(String oRD_ID) {
		ORD_ID = oRD_ID;
	}
	public String getCus_id() {
		return Cus_id;
	}
	public void setCus_id(String cus_id) {
		Cus_id = cus_id;
	}
	public String getVEN_ID() {
		return VEN_ID;
	}
	public void setVEN_ID(String vEN_ID) {
		VEN_ID = vEN_ID;
	}
	public String getWAL_SOURCE() {
		return WAL_SOURCE;
	}
	public void setWAL_SOURCE(String wAL_SOURCE) {
		WAL_SOURCE = wAL_SOURCE;
	}
	public String getMEN_ID() {
		return MEN_ID;
	}
	public void setMEN_ID(String mEN_ID) {
		MEN_ID = mEN_ID;
	}
	public String getORD_DATE() {
		return ORD_DATE;
	}
	public void setORD_DATE(String oRD_DATE) {
		ORD_DATE = oRD_DATE;
	}
	public String getORD_QUANTITY() {
		return ORD_QUANTITY;
	}
	public void setORD_QUANTITY(String oRD_QUANTITY) {
		ORD_QUANTITY = oRD_QUANTITY;
	}
	public String getORD_BILLAMOUNT() {
		return ORD_BILLAMOUNT;
	}
	public void setORD_BILLAMOUNT(String oRD_BILLAMOUNT) {
		ORD_BILLAMOUNT = oRD_BILLAMOUNT;
	}
	public String getORD_STATUS() {
		return ORD_STATUS;
	}
	public void setORD_STATUS(String oRD_STATUS) {
		ORD_STATUS = oRD_STATUS;
	}
	public String getORD_COMMENTS() {
		return ORD_COMMENTS;
	}
	public void setORD_COMMENTS(String oRD_COMMENTS) {
		ORD_COMMENTS = oRD_COMMENTS;
	}
    
    
}
